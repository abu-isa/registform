
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
          <li class="">
            <a class="" href="{{ url('/admin/home') }}">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
          </li>
          <li>
            <a class="" href="{{ url('/listseminar') }}">
                          <i class="icon_desktop"></i>
                          <span>Seminar</span>
                      </a>
          </li>

          <li>
            <a class="" href="{{ url('/listregistration') }}">
                          <i class="icon_document_alt"></i>
                          <span>Registration</span>
                      </a>
          </li>
          <li>
            <a class="" href="{{ url('/report') }}">
                          <i class="icon_piechart"></i>
                          <span>Report</span>

                      </a>

          </li> 

        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
