 <!--main content end-->
    <div class="text-right">
      <div class="credits">
          <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
          -->
         Designed by <a href="">SIDANAR</a>
        </div>
    </div>
  </section>
  <!-- container section end -->
  <!-- javascripts -->
  <script src="{{ asset('template/js/jquery.js') }}"></script>
  <script src="{{ asset('template/js/bootstrap.min.js') }}"></script>
  <!-- nicescroll -->
  <script src="{{ asset('template/js/jquery.scrollTo.min.js') }}"></script>
  <script src="{{ asset('template/js/jquery.nicescroll.js') }}" type="text/javascript"></script>
  <!--custome script for all page-->
  <script src="{{ asset('template/js/scripts.js') }}"></script>


</body>

</html>
